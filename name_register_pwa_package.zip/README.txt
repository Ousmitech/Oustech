# Name Register PWA

Upload all files in this folder to a static HTTPS host. Keep `index.html` at the site root.
Then open the HTTPS site in Android Chrome, open the three-dot menu, and choose **Install app** or **Add to Home screen**.

Records are stored in the browser's local storage on that device. They are not sent to the hosting site. Export CSV regularly as a backup. Clearing browser/site data can erase the saved records.
